﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DisplayStudentDemo.Models;

namespace DisplayStudentDemo.Controllers
{
    public class StudentController : Controller
    {
        TrainingEntities context = new TrainingEntities();
        //
        // GET: /Student/
        public ActionResult Index()
        {
            var query = context.Student_master.Where(s => s.Address == "Mumbai");

            ViewBag.StudList = query.ToList();

            return View();
        }

        //city = pune and birth year is 1995, sort in descending name
        public ActionResult DisplayStudPune()
        {
            //var query = context.Student_master.Where(s => s.Address == "Pune" && s.Stud_Dob.Value.Year == 1995).OrderByDescending(s => s.Stud_Name);

            var query = from stud in context.Student_master
                        where stud.Address == "Pune" && stud.Stud_Dob.Value.Year == 1995
                        orderby stud.Stud_Name descending
                        select stud;

            ViewBag.StudList = query.ToList();

            // return View();
            return Redirect("Index");
        }

        //city not provided

        public ActionResult DisplayCity()
        {
            var query = context.Student_master.Where(s => s.Address == null);

            ViewBag.StudList = query.ToList();

            return View();
        }

        //whose birth year is withing 1989 to 1996
        public ActionResult DisplayYear()
        {
            var query = context.Student_master.Where(s => s.Stud_Dob.Value.Year >= 1989 && s.Stud_Dob.Value.Year <= 1996);

            ViewBag.StudList = query.ToList();

            return View();
        }

        //date of birth from 1-Jun-1991 to 4-Apr-1994
        public ActionResult DisplayDOB()
        {
            var query = context.Student_master.Where(s => s.Stud_Dob.Value >= new DateTime(1991, 6, 1) && s.Stud_Dob.Value <= new DateTime(1994, 4, 4));
            //var query = context.Student_master.Where(s => s.Stud_Dob.Value >= Convert.ToDateTime("06/01/1991") && s.Stud_Dob.Value <= Convert.ToDateTime("04/04/1994"));

            ViewBag.StudList = query.ToList();

            return View();
        }

        //department code is 10 or city is pune
        public ActionResult DisplayDeptCity()
        {
            var query = context.Student_master.Where(s => s.Dept_Code == 10 || s.Address == "Pune");

            ViewBag.StudList = query.ToList();

            return View();
        }

	}
}